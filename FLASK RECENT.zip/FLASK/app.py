from flask import Flask, render_template
from settings import app
from models import *

@app.route('/')
def index():
    tcount = db.engine.execute(f"SELECT count('T_ID') from TRAINERS").scalar()
    mcount = db.engine.execute(f"SELECT count('M_ID') from MEMBERS").scalar()
    excount = db.engine.execute(f"SELECT count('E_ID') from EXERCISE").scalar()
    eqcount = db.engine.execute(f"SELECT count('EQ_ID') from EQUIPMENTS").scalar()
    pcount = db.engine.execute(f"SELECT count('P_ID') from PACKAGE").scalar()
    topMembers = db.session.execute('SELECT * FROM members order by M_JOINDATE DESC limit 5')
    top_members = [row for row in topMembers]
    print(top_members)

    return render_template('/Dashboard/index.html', title="Dashboard" , icon="glyphicon-cog", isactive="active" , tcount = tcount , mcount = mcount , excount = excount , eqcount = eqcount , pcount = pcount ,top_members = top_members)

@app.route('/home')
def home():
    return render_template('home.html' , title="TGYM")

@app.route('/login')
def dashboard():
    return render_template('/Dashboard/login.html')

if __name__ == "__main__":
    app.run(debug=True)